import {defineConfig} from 'vite';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({define:{"process.env.NODE_ENV":JSON.stringify("production")},plugins:[tailwindcss()],resolve:{alias:{'@':new URL('.',import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1')}},build:{outDir:'dist',emptyOutDir:true,lib:{entry:'main.tsx',formats:['es'],fileName:()=> 'effects.js',cssFileName:'effects'},rollupOptions:{output:{inlineDynamicImports:true}}}});
