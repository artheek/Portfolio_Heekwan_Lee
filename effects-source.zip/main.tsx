import React from 'react';
import {createRoot} from 'react-dom/client';
import {useReducedMotion} from 'motion/react';
import {GlowEffect} from '@/components/ui/glow-effect';
import {SparklesCore} from '@/components/ui/sparkles';
import './effects.css';
function Background(){const reduced=useReducedMotion();return reduced?null:<SparklesCore id="portfolio-sparkles" background="transparent" minSize={0.5} maxSize={1.3} particleDensity={32} particleColor="#8dbbe0" speed={0.5} className="h-full w-full"/>;}
function Glow(){return <GlowEffect colors={['#0894FF','#C959DD','#FF2E54','#FF9004']} mode="static" blur="medium"/>;}
const background=document.querySelector('#sparkles-root');
if(background)createRoot(background).render(<Background/>);
document.querySelectorAll('.glow-mount').forEach(el=>createRoot(el).render(<Glow/>));
