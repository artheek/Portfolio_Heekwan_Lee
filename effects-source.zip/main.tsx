import React from 'react';
import {createRoot} from 'react-dom/client';
import {GlowEffect} from '@/components/ui/glow-effect';
import {SparklesPreview} from '@/components/ui/sparkles-demo';
import './effects.css';
function Glow(){return <GlowEffect colors={['#0894FF','#C959DD','#FF2E54','#FF9004']} mode="static" blur="medium"/>;}
const background=document.querySelector('#sparkles-root');
if(background)createRoot(background).render(<SparklesPreview/>);
document.querySelectorAll('.glow-mount').forEach(el=>createRoot(el).render(<Glow/>));
