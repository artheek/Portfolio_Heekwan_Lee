import React, {useEffect, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {GlowEffect} from '@/components/ui/glow-effect';
import {SparklesCore} from '@/components/ui/sparkles';
import './effects.css';
function SelectionEffect({target}:{target:HTMLElement}) {
  const [active,setActive]=useState(false);
  useEffect(()=>{
    const enter=()=>setActive(true),leave=()=>setActive(false);
    target.addEventListener('pointerenter',enter);target.addEventListener('pointerleave',leave);
    target.addEventListener('focus',enter);target.addEventListener('blur',leave);
    return ()=>{target.removeEventListener('pointerenter',enter);target.removeEventListener('pointerleave',leave);target.removeEventListener('focus',enter);target.removeEventListener('blur',leave);};
  },[target]);
  if(!active)return null;
  return <><div className="selection-border"/><div className="selection-outward"><SparklesCore outward background="transparent" minSize={0.4} maxSize={1} particleDensity={1200} className="sparkle-canvas" particleColor="#FFFFFF"/></div></>;
}
function mountSelections(){document.querySelectorAll<HTMLElement>('.category-link,.clip-media').forEach(target=>{
  if(target.querySelector('.selection-effect'))return;
  const host=document.createElement('span');host.className='selection-effect';host.setAttribute('aria-hidden','true');
  (target.querySelector('.thumbnail-frame')||target).append(host);
  createRoot(host).render(<SelectionEffect target={target}/>);
});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mountSelections);else mountSelections();
