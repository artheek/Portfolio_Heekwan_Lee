# Portfolio React effects

React + TypeScript + Tailwind CSS v4, with shadcn-compatible aliases and components.json.

- components/ui/glow-effect.tsx: supplied GlowEffect, used in static mode around the two category cards.
- components/ui/sparkles.tsx: supplied SparklesCore, configured with 30 fps and no click-to-add particles.
- main.tsx: mounts effects onto the existing static portfolio.
- lib/utils.ts: cn helper.
- effects.css: Tailwind theme/utilities only, without preflight to preserve existing layout.

The components/ui directory is used by shadcn aliases and keeps reusable UI separate from page markup. Existing project setup is included; no CLI initialization is necessary.

Run npm ci, then npm run build. Copy dist/effects.js and dist/effects.css to the portfolio root. The production bundle includes its dependencies and needs no runtime CDN.

Numeric GlowEffect blur uses an inline filter instead of a dynamic Tailwind class. Sparkles respects reduced-motion through the mounting component. The original supplied engine v3 API is retained for compatibility.
